from flask import Flask


app = Flask(__name__)

app.secret_key = "1d046f91c0848b41e6fb0dade6c9a4b0306bcd85f7a82114e5eef46b7cf3b3b9"
