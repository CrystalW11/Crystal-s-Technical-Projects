function Signout(element) {
    element.innerText = "Logout";
}
function disappearbutton(element) {
    element.remove()
}
