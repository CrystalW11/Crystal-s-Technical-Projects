function disappearbutton(element) {
    element.remove()
}

( "#cart_image" ).click(function() {
    alert( "Your Cart is empty" );
  });