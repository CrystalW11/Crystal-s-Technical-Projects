/** @format */

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const DisplayAll = (props) => {
  const [meals, setMeals] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:8000/api/meals")
      .then((res) => {
        console.log(res.data);
        setMeals(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  return (
    <>
      <div className="container">
        <h2>Find inspiration with these delicious meals!</h2>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Meal</th>
              <th>Prep Time</th>
              <th>Options</th>
            </tr>
          </thead>
          <tbody>
            {meals.map((meal) => (
              <tr key={meal._id}>
                <td>{meal.dishName}</td>
                <td>{meal.totalMinutes}</td>

                <td>
                  <Link className="" to={`/meals/${meal._id}/details`}>
                    Meal Details
                  </Link>{" "}
                  | <Link to={`/meals/${meal._id}/edit`}>Edit</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default DisplayAll;
